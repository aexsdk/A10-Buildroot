#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#define __REG(x)	  (*(volatile unsigned int *)(x))
#define REGS_pBASE				0x01C00000		

#define EGON_RESET_BASE                 0xFFFF0000
#define FEL_BASE                        ( EGON_RESET_BASE + 0x20 )

#define CCMU_REGS_pBASE			( REGS_pBASE + 0x20000 )    //clock manager unit
#define CCMU_REGS_BASE			CCMU_REGS_pBASE				  //clock manager unit
#define bCCMU_CTL(Nb)			__REG(CCMU_REGS_BASE + (Nb))
#define CCMU_REG_o_APBMOD		0x10
#define CCMU_REG_APBMOD			bCCMU_CTL(CCMU_REG_o_APBMOD     )

#define CCMU_BP_UART3_APB_GATE              8
#define CCMU_BP_UART2_APB_GATE              7
#define CCMU_BP_UART1_APB_GATE              6
#define CCMU_BP_UART0_APB_GATE              5

#define PIOC_REGS_pBASE					( REGS_pBASE + 0x20800 )    //general perpose I/O
#define PIOC_REGS_BASE					PIOC_REGS_pBASE				  //general perpose I/O
#define PIOC_REG_o_B_PULL0				0x38
#define PIOC_REG_B_PULL0				__REG( PIOC_REGS_BASE + PIOC_REG_o_B_PULL0       )
#define PIOC_REG_o_B_PULL1          0x3C
#define PIOC_REG_B_PULL1            __REG( PIOC_REGS_BASE + PIOC_REG_o_B_PULL1       )
#define PIOC_REG_o_B_CFG0				0x20
#define PIOC_REG_B_CFG0					__REG( PIOC_REGS_BASE + PIOC_REG_o_B_CFG0        )
#define PIOC_REG_o_B_CFG1				0x24
#define PIOC_REG_B_CFG1					__REG( PIOC_REGS_BASE + PIOC_REG_o_B_CFG1        )
#define PIOC_REG_o_B_CFG2           0x28
#define PIOC_REG_B_CFG2             __REG( PIOC_REGS_BASE + PIOC_REG_o_B_CFG2        )
#define PIOC_REG_o_A_CFG0           0x00
#define PIOC_REG_A_CFG0             __REG( PIOC_REGS_BASE + PIOC_REG_o_A_CFG0        )
#define PIOC_REG_o_A_PULL0          0x18
#define PIOC_REG_A_PULL0            __REG( PIOC_REGS_BASE + PIOC_REG_o_A_PULL0       )

#define	TIME_REGS_BASE					0x01c20c00
#define	TIME_REG_AVS_CTRL				(TIME_REGS_BASE + 0x0038)
#define	TIME_REG_AVS_C0				(TIME_REGS_BASE + 0x003C)
#define	TIME_REG_AVS_C1				(TIME_REGS_BASE + 0x0040)
#define	TIME_REG_AVS_DIV				(TIME_REGS_BASE + 0x0044)
#define	CCMU_REG_AVS_CLK				(0x01c20000 + 0x0040)
#define	AVS_CNT0_PS						(1 << 8)
#define	AVS_CNT0_EN						(1 << 0)
#define	AVS_CNT0_D						(0)

#define UART0_REGS_pBASE        ( REGS_pBASE + 0x21000 )    //uart0
#define UART1_REGS_pBASE        ( REGS_pBASE + 0x21400 )    //uart1
#define UART2_REGS_pBASE        ( REGS_pBASE + 0x21800 )    //uart2
#define UART3_REGS_pBASE        ( REGS_pBASE + 0x21c00 )    //uart3

#define UART0_REGS_BASE 	 UART0_REGS_pBASE 			  //uart0
#define UART1_REGS_BASE 	 UART1_REGS_pBASE 			  //uart1
#define UART2_REGS_BASE 	 UART2_REGS_pBASE 			  //uart2
#define UART3_REGS_BASE 	 UART3_REGS_pBASE 			  //uart3

#define _set_bit( x, y )      			( (x) |=  ( 1U << (y) ) )
#define _clear_bit( x, y )    			( (x) &= ~( 1U << (y) ) )

#endif

