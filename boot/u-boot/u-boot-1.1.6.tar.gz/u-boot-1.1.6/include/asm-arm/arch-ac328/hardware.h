#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#define __REG(x)            (*(volatile unsigned int *)(x))
#define REGS_pBASE          0x01C00000


//---------------------------------------------------
// memory address base
//---------------------------------------------------
//SRAM ADDRESS BASE
#define SRAM_A1_BASE    0x00000000      //16k bytes
#define SRAM_A2_BASE    0X00004000      //16k bytes
#define SRAM_A3_BASE    0X00008000      //13k bytes
#define SRAM_A4_BASE    0X0000b400      //3k  bytes
#define SRAM_D_BASE     0X00010000      //4k  bytes
#define SRAM_B_BASE     0X00020000      //64k bytes, Secure
//DRAM ADDRESS BASE
#define DRAM_BASE       0x40000000      //2G  bytes
//ROM ADDRESS BASE
#define ROM_BASE        0xffff0000      //64k bytes


//---------------------------------------------------
// register address base
//---------------------------------------------------
#define SRAM_CTRL_BASE      (REGS_pBASE + 0x00000000)
#define DRAM_CTRL_BASE      (REGS_pBASE + 0x00001000)
#define DMA_CTRL_BASE       (REGS_pBASE + 0x00002000)
#define NFC_CTRL_BASE       (REGS_pBASE + 0x00003000)
#define TS_CTRL_BASE        (REGS_pBASE + 0x00004000)
#define SPI0_CTRL_BASE      (REGS_pBASE + 0x00005000)
#define SPI1_CTRL_BASE      (REGS_pBASE + 0x00006000)
#define MS_CTRL_BASE        (REGS_pBASE + 0x00007000)
#define TVD_CTRL_BASE       (REGS_pBASE + 0x00008000)
#define CSI0_CTRL_BASE      (REGS_pBASE + 0x00009000)
#define TVE0_CTRL_BASE      (REGS_pBASE + 0x0000a000)
#define EMAC_CTRL_BASE      (REGS_pBASE + 0x0000b000)
#define LCD0_CTRL_BASE      (REGS_pBASE + 0x0000c000)
#define LCD1_CTRL_BASE      (REGS_pBASE + 0x0000d000)
#define VE_CTRL_BASE        (REGS_pBASE + 0x0000e000)
#define SDMMC0_CTRL_BASE    (REGS_pBASE + 0x0000f000)
#define SDMMC1_CTRL_BASE    (REGS_pBASE + 0x00010000)
#define SDMMC2_CTRL_BASE    (REGS_pBASE + 0x00011000)
#define SDMMC3_CTRL_BASE    (REGS_pBASE + 0x00012000)
#define USB0_CTRL_BASE      (REGS_pBASE + 0x00013000)
#define USB1_CTRL_BASE      (REGS_pBASE + 0x00014000)
#define SS_CTRL_BASE        (REGS_pBASE + 0x00015000)
#define HDMI_CTRL_BASE      (REGS_pBASE + 0x00016000)
#define SPI2_CTRL_BASE      (REGS_pBASE + 0x00017000)
#define SATA_CTRL_BASE      (REGS_pBASE + 0x00018000)
#define PATA_CTRL_BASE      (REGS_pBASE + 0x00019000)
#define ACE_CTRL_BASE       (REGS_pBASE + 0x0001a000)
#define TVE1_CTRL_BASE      (REGS_pBASE + 0x0001b000)
#define USB2_CTRL_BASE      (REGS_pBASE + 0x0001c000)
#define CSI1_CTRL_BASE      (REGS_pBASE + 0x0001d000)
#define TZASC_CTRL_BASE     (REGS_pBASE + 0x0001e000)
#define SPI3_CTRL_BASE      (REGS_pBASE + 0x0001f000)
#define CCM_CTRL_BASE       (REGS_pBASE + 0x00020000)
#define INTC_CTRL_BASE      (REGS_pBASE + 0x00020400)
#define PIO_CTRL_BASE       (REGS_pBASE + 0x00020800)
#define TIMER_CTRL_BASE     (REGS_pBASE + 0x00020c00)
#define SPDIF_CTRL_BASE     (REGS_pBASE + 0x00021000)
#define AC97_CTRL_BASE      (REGS_pBASE + 0x00021400)
#define IR0_CTRL_BASE       (REGS_pBASE + 0x00021800)
#define IR1_CTRL_BASE       (REGS_pBASE + 0x00021c00)
#define IIS_CTRL_BASE       (REGS_pBASE + 0x00022400)
#define LRADC_CTRL_BASE     (REGS_pBASE + 0x00022800)
#define ADDA_CTRL_BASE      (REGS_pBASE + 0x00022c00)
#define KEYPAD_CTRL_BASE    (REGS_pBASE + 0x00023000)
#define TZPC_CTRL_BASE      (REGS_pBASE + 0x00023400)
#define SID_CTRL_BASE       (REGS_pBASE + 0x00023800)
#define SJTAG_CTRL_BASE     (REGS_pBASE + 0x00023c00)
#define TP_CTRL_BASE        (REGS_pBASE + 0x00025000)
#define PMU_CTRL_BASE       (REGS_pBASE + 0x00025400)
#define UART0_CTRL_BASE     (REGS_pBASE + 0x00028000)
#define UART1_CTRL_BASE     (REGS_pBASE + 0x00028400)
#define UART2_CTRL_BASE     (REGS_pBASE + 0x00028800)
#define UART3_CTRL_BASE     (REGS_pBASE + 0x00028c00)
#define UART4_CTRL_BASE     (REGS_pBASE + 0x00029000)
#define UART5_CTRL_BASE     (REGS_pBASE + 0x00029400)
#define UART6_CTRL_BASE     (REGS_pBASE + 0x00029800)
#define UART7_CTRL_BASE     (REGS_pBASE + 0x00029c00)
#define PS20_CTRL_BASE      (REGS_pBASE + 0x0002a000)
#define PS21_CTRL_BASE      (REGS_pBASE + 0x0002a400)
#define TWI0_CTRL_BASE      (REGS_pBASE + 0x0002ac00)
#define TWI1_CTRL_BASE      (REGS_pBASE + 0x0002b000)
#define TWI2_CTRL_BASE      (REGS_pBASE + 0x0002b400)
#define CAN0_CTRL_BASE      (REGS_pBASE + 0x0002bc00)
#define CAN1_CTRL_BASE      (REGS_pBASE + 0x0002c000)
#define SCR_CTRL_BASE       (REGS_pBASE + 0x0002c400)
#define GPS_CTRL_BASE       (REGS_pBASE + 0x00030000)
#define MALI_CTRL_BASE      (REGS_pBASE + 0x00040000)
#define DEFE0_CTRL_BASE     (REGS_pBASE + 0x00200000)
#define DEFE1_CTRL_BASE     (REGS_pBASE + 0x00220000)
#define DEBE0_CTRL_BASE     (REGS_pBASE + 0x00260000)
#define DEBE1_CTRL_BASE     (REGS_pBASE + 0x00240000)
#define MP_CTRL_BASE        (REGS_pBASE + 0x00280000)
#define AVG_CTRL_BASE       (REGS_pBASE + 0x002a0000)

#define EGON_RESET_BASE     0xFFFF0000
#define FEL_BASE            ( EGON_RESET_BASE + 0x20 )

#define UART0_REGS_BASE      UART0_CTRL_BASE
#define UART1_REGS_BASE      UART1_CTRL_BASE
#define UART2_REGS_BASE      UART2_CTRL_BASE
#define UART3_REGS_BASE      UART3_CTRL_BASE

#define _set_bit( x, y )        ( (x) |=  ( 1U << (y) ) )
#define _clear_bit( x, y )      ( (x) &= ~( 1U << (y) ) )

#endif

