/*
 *      Davicom WEMAC Fast Ethernet driver for Linux.
 * 	Copyright (C) 1997  Sten Wang
 *
 * 	This program is free software; you can redistribute it and/or
 * 	modify it under the terms of the GNU General Public License
 * 	as published by the Free Software Foundation; either version 2
 * 	of the License, or (at your option) any later version.
 *
 * 	This program is distributed in the hope that it will be useful,
 * 	but WITHOUT ANY WARRANTY; without even the implied warranty of
 * 	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * 	GNU General Public License for more details.
 *
 * (C) Copyright 1997-1998 DAVICOM Semiconductor,Inc. All Rights Reserved.
 *
 * Additional updates, Copyright:
 *	Ben Dooks <ben@simtec.co.uk>
 *	Sascha Hauer <s.hauer@pengutronix.de>
 */

#include "wemac.h"
#include <asm/types.h>
#include <common.h>
#include <malloc.h>
#include <net.h>
#include <asm/io.h>

#define dbg_print printf
/* Board/System/Debug information/definition ---------------- */

#define WEMAC_PHY		0x100	/* PHY address 0x01 */

#define CARDNAME	"wemac"
#define DRV_VERSION	"1.00"

/*
 * Transmit timeout, default 5 seconds.
 */
unsigned char DEFAULT_MAC_ADDR[6]={0x3a, 0x9d, 0x33, 0x28, 0xd2, 0x00};
static char wemac_packet[2096];

/* WEMAC register address locking.
 *
 * The WEMAC uses an address register to control where data written
 * to the data register goes. This means that the address register
 * must be preserved over interrupts or similar calls.
 *
 * During interrupt and other critical calls, a spinlock is used to
 * protect the system, but the calls themselves save the address
 * in the address register in case they are interrupting another
 * access to the device.
 *
 * For general accesses a lock is provided so that calls which are
 * allowed to sleep are serialised so that the address register does
 * not need to be saved. This lock also serves to serialise access
 * to the EEPROM and PHY access registers which are shared between
 * these two devices.
 */

/* The driver supports the original WEMACE, and now the two newer
 * devices, WEMACA and WEMACB.
 */


/* Structure/enum declaration ------------------------------- */
struct wemac_rxhdr {
	__s16	RxLen;
	__u16	RxStatus;
} __attribute__((__packed__));

typedef struct wemac_board_info {

	char *emac_base;	/* mac I/O base address */
	char *sram_base;	/* sram control I/O base address */
	char *gpio_base;	/* gpio I/O base address */
	char *ccmu_base;	/* ccmu I/O base address */

	void (*inblk)(void  *port, void *data, int length);
	void (*outblk)(void  *port, void *data, int length);
	void (*dumpblk)(void  *port, int length);

} wemac_board_info_t;


static int wemac_phy_read(wemac_board_info_t * db, int phyaddr_unused, int reg);
static void wemac_phy_write(wemac_board_info_t * db, int phyaddr_unused, int reg, int value);


/* WEMAC network board routine ---------------------------- */

static void
wemac_reset(wemac_board_info_t * db)
{
	printf("resetting device\n");

	/* RESET device */
	writel(0, db->emac_base + EMAC_CTL_REG);
	udelay(200);
	writel(1, db->emac_base + EMAC_CTL_REG);
	udelay(200);
}

static void wemac_outblk_32bit(void   *reg, void *data, int count)
{
	int i;
	for(i=0;i<((count+3) >> 2);i++)
		writel(((int*)data)[i], reg);
}

static void wemac_inblk_32bit(void   *reg, void *data, int count)
{
	int i;
	for(i=0;i<((count+3) >> 2);i++)
		((int*)data)[i] = readl(reg);
}

static void wemac_dumpblk_32bit(void   *reg, int count)
{
	int i;
	int tmp;

	count = (count + 3) >> 2;

	for (i = 0; i < count; i++)
		tmp = readl(reg);
}

void emac_sys_setup(wemac_board_info_t * db)
{
	unsigned int reg_val;

	//map SRAM to EMAC
	  reg_val = readl(db->sram_base + SRAMC_CFG_REG);  //set up SRAM config register
	  reg_val |= 0x5<<4;
	  writel(reg_val, db->sram_base + SRAMC_CFG_REG);
	
	//set up PIO
	#ifdef EMAC_MAP0
	
	reg_val = readl(db->gpio_base + PB_CFG2_REG);
	reg_val &=~(0x7<<0);  //PIOB16
	reg_val |= 0x4<<0;
	reg_val &=~(0x7<<4);  //PIOB17
	reg_val |= 0x4<<4;
	writel(reg_val, db->gpio_base + PB_CFG2_REG);
	
	reg_val = readl(db->gpio_base + PD_CFG0_REG);
	reg_val &=~(0x7<<0);  //PIOD0
	reg_val |= 0x3<<0;
	reg_val &=~(0x7<<4);  //PIOD1
	reg_val |= 0x3<<4;
	reg_val &=~(0x7<<8);  //PIOD2
	reg_val |= 0x3<<8;
	writel(reg_val, db->gpio_base + PD_CFG0_REG);

	reg_val = readl(db->gpio_base + PD_CFG1_REG);
	reg_val &=~(0x7<<0);  //PIOD8
	reg_val |= 0x3<<0;
	reg_val &=~(0x7<<4);  //PIOD9
	reg_val |= 0x3<<4;
	reg_val &=~(0x7<<20);  //PIOD13
	reg_val |= 0x3<<20;
	reg_val &=~(0x7<<24);  //PIOD13
	reg_val |= 0x3<<24;
	reg_val &=~(0x7<<28);  //PIOD13
	reg_val |= 0x3<<28;
	writel(reg_val, db->gpio_base + PD_CFG1_REG);
	
	reg_val = readl(db->gpio_base + PD_CFG2_REG);
	reg_val &=~(0x7<<16);  //PIOD20
	reg_val |= 0x3<<16;
	reg_val &=~(0x7<<20);  //PIOD21
	reg_val |= 0x3<<20;
	reg_val &=~(0x7<<24);  //PIOD22
	reg_val |= 0x3<<24;
	reg_val &=~(0x7<<28);  //PIOD23
	reg_val |= 0x3<<28;
	writel(reg_val, db->gpio_base + PD_CFG2_REG);
	
	reg_val = readl(db->gpio_base + PD_CFG3_REG);
	reg_val &=~(0x7<<0);  //PIOD24
	reg_val |= 0x3<<0;
	reg_val &=~(0x7<<4);  //PIOD25
	reg_val |= 0x3<<4;
	reg_val &=~(0x7<<8);  //PIOD26
	reg_val |= 0x3<<8;
	reg_val &=~(0x7<<12);  //PIOD27
	reg_val |= 0x3<<12;
	writel(reg_val, db->gpio_base + PD_CFG3_REG);
	#endif
	
	#ifdef EMAC_MAP1
	
	reg_val = readl(db->gpio_base + PA_CFG0_REG);
	reg_val &=~(0x7<<8);  //PIOA2
	reg_val |= 0x2<<8;
	reg_val &=~(0x7<<12);  //PIOA3
	reg_val |= 0x2<<12;
	reg_val &=~(0x7<<16);  //PIOA4
	reg_val |= 0x2<<16;
	reg_val &=~(0x7<<20);  //PIOA5
	reg_val |= 0x2<<20;
	reg_val &=~(0x7<<24);  //PIOA6
	reg_val |= 0x2<<24;
	reg_val &=~(0x7<<28);  //PIOA7
	reg_val |= 0x2<<28;
	writel(reg_val, db->gpio_base + PA_CFG0_REG);
	
	reg_val = readl(db->gpio_base + PA_CFG1_REG);
	reg_val &=~(0x7<<0);  //PIOA8
	reg_val |= 0x2<<0;
	reg_val &=~(0x7<<4);  //PIOA9
	reg_val |= 0x2<<4;
	reg_val &=~(0x7<<8);  //PIOA10
	reg_val |= 0x2<<8;
	reg_val &=~(0x7<<12);  //PIOA11
	reg_val |= 0x2<<12;
	reg_val &=~(0x7<<16);  //PIOA12
	reg_val |= 0x2<<16;
	reg_val &=~(0x7<<20);  //PIOA13
	reg_val |= 0x2<<20;
	reg_val &=~(0x7<<24);  //PIOA14
	reg_val |= 0x2<<24;
	reg_val &=~(0x7<<28);  //PIOA15
	reg_val |= 0x2<<28;
	writel(reg_val, db->gpio_base + PA_CFG1_REG);
	
	reg_val = readl(db->gpio_base + PA_CFG2_REG);
	reg_val &=~(0x7<<0);  //PIOA16
	reg_val |= 0x2<<0;
	reg_val &=~(0x7<<4);  //PIOA17
	reg_val |= 0x2<<4;
	reg_val &=~(0x7<<8);  //PIOA18
	reg_val |= 0x2<<8;

	reg_val &=~(0x7<<12);  //PIOA19
	reg_val |= 0x2<<8;
	writel(reg_val, db->gpio_base + PA_CFG2_REG);

	#endif
	
	
	//set up clock gating
	reg_val = readl(db->ccmu_base + CCM_AHB_GATING_REG);
	reg_val |= 0x1<<17;			//EMAC
	writel(reg_val, db->ccmu_base + CCM_AHB_GATING_REG);
	
	
}

unsigned int emac_setup(wemac_board_info_t * db )
{
	unsigned int reg_val;
	unsigned int phy_val;
	unsigned int duplex_flag;
	
//     dbg_print("EMAC seting ==>\n" 
//         "PHY_AUTO_NEGOTIOATION  %x  0: Normal        1: Auto                 \n"
//         "PHY_SPEED              %x  0: 10M           1: 100M                 \n"
//         "EMAC_MAC_FULL          %x  0: Half duplex   1: Full duplex          \n"
//         "EMAC_TX_TM             %x  0: CPU           1: DMA                  \n"
//         "EMAC_TX_AB_M           %x  0: Disable       1: Aborted frame enable \n"
//         "EMAC_RX_TM             %x  0: CPU           1: DMA                  \n"
//         "EMAC_RX_DRQ_MODE       %x  0: DRQ asserted  1: DRQ automatically    \n"
//         ,PHY_AUTO_NEGOTIOATION 
//         ,PHY_SPEED             
//         ,EMAC_MAC_FULL         
//         ,EMAC_TX_TM            
//         ,EMAC_TX_AB_M          
//         ,EMAC_RX_TM            
//         ,EMAC_RX_DRQ_MODE);
	
	//set up TX
	reg_val = readl(db->emac_base + EMAC_TX_MODE_REG);
	
	if(EMAC_TX_AB_M)
		reg_val |= 0x1;
	else
		reg_val &= (~0x1);
		
	if(EMAC_TX_TM)
		reg_val |= (0x1<<1);
	else
		reg_val &= (~(0x1<<1));
	
	writel(reg_val, db->emac_base + EMAC_TX_MODE_REG);
	
	//set up RX
	reg_val = readl(db->emac_base + EMAC_RX_CTL_REG);
	
	if(EMAC_RX_DRQ_MODE)
		reg_val |= (0x1<<1);
	else
		reg_val &= (~(0x1<<1));	
		
	if(EMAC_RX_TM)
		reg_val |= (0x1<<2);
	else
		reg_val &= (~(0x1<<2));
	
	if(EMAC_RX_PA)
		reg_val |= (0x1<<4);
	else
		reg_val &= (~(0x1<<4));
	
	if(EMAC_RX_PCF)
		reg_val |= (0x1<<5);
	else
		reg_val &= (~(0x1<<5));
		
	if(EMAC_RX_PCRCE)
		reg_val |= (0x1<<6);
	else
		reg_val &= (~(0x1<<6));
	
	if(EMAC_RX_PLE)
		reg_val |= (0x1<<7);
	else
		reg_val &= (~(0x1<<7));
		
	if(EMAC_RX_POR)
		reg_val |= (0x1<<8);
	else
		reg_val &= (~(0x1<<8));
	
	if(EMAC_RX_UCAD)
		reg_val |= (0x1<<16);
	else
		reg_val &= (~(0x1<<16));
	
	if(EMAC_RX_DAF)
		reg_val |= (0x1<<17);
	else
		reg_val &= (~(0x1<<17));
	
	if(EMAC_RX_MCO)
		reg_val |= (0x1<<20);
	else
		reg_val &= (~(0x1<<20));
	
	if(EMAC_RX_MHF)
		reg_val |= (0x1<<21);
	else
		reg_val &= (~(0x1<<21));
	
	if(EMAC_RX_BCO)
		reg_val |= (0x1<<22);
	else
		reg_val &= (~(0x1<<22));
	
	if(EMAC_RX_SAF)
		reg_val |= (0x1<<24);
	else
		reg_val &= (~(0x1<<24));
	
	if(EMAC_RX_SAIF)
		reg_val |= (0x1<<25);
	else
		reg_val &= (~(0x1<<25));
	
	writel(reg_val, db->emac_base + EMAC_RX_CTL_REG);
	
  //set MAC
  //set MAC CTL0
	reg_val = readl(db->emac_base + EMAC_MAC_CTL0_REG);
	
	if(EMAC_MAC_TFC)
		reg_val |= (0x1<<3);
	else
		reg_val &= (~(0x1<<3));
		
	if(EMAC_MAC_RFC)
		reg_val |= (0x1<<2);
	else
		reg_val &= (~(0x1<<2));
		
	writel(reg_val, db->emac_base + EMAC_MAC_CTL0_REG);
	
	//set MAC CTL1
	reg_val = readl(db->emac_base + EMAC_MAC_CTL1_REG);

	//phy setup
	if(!PHY_AUTO_NEGOTIOATION)
	{
		phy_val = wemac_phy_read(db, 0, 0);
		printf("PHY reg 0 value: %x\n", phy_val);

		phy_val = (PHY_SPEED<<13)|(EMAC_MAC_FULL<<8) ;
		printf("PHY SETUP, write reg 0 with value: %x\n", phy_val);
		wemac_phy_write(db, 0, 0, phy_val);
		
		//soft reset phy
		phy_val = wemac_phy_read(db, 0, 0);
		phy_val |= 0x1<<15;
		wemac_phy_write(db, 0, 0, phy_val);

		phy_val = wemac_phy_read(db, 0, 0);
		printf("PHY reg 0 value: %x\n", phy_val);

		udelay(10000);
		phy_val = (PHY_SPEED<<13)|(EMAC_MAC_FULL<<8) ;
		printf("PHY SETUP, write reg 0 with value: %x\n", phy_val);
		wemac_phy_write(db, 0, 0, phy_val);
	}
	udelay(10);
	phy_val = wemac_phy_read(db, 0, 0);
	printf("PHY SETUP, reg 0 value: %x\n", phy_val);
	duplex_flag = !! (phy_val & (1<<8));
	
	if(PHY_AUTO_NEGOTIOATION)
	{ 
		if(duplex_flag)
			reg_val |= (0x1<<0);
		else
			reg_val &= (~(0x1<<0));
	}
	else
	{
		if(EMAC_MAC_FULL)
			reg_val |= (0x1<<0);
		else
			reg_val &= (~(0x1<<0));
	}
		
	if(EMAC_MAC_FLC)
		reg_val |= (0x1<<1);
	else
		reg_val &= (~(0x1<<1));
		
	if(EMAC_MAC_HF)
		reg_val |= (0x1<<2);
	else
		reg_val &= (~(0x1<<2));
		
	if(EMAC_MAC_DCRC)
		reg_val |= (0x1<<3);
	else
		reg_val &= (~(0x1<<3));	
		
	if(EMAC_MAC_CRC)
		reg_val |= (0x1<<4);
	else
		reg_val &= (~(0x1<<4));			
	
	if(EMAC_MAC_PC)
		reg_val |= (0x1<<5);
	else
		reg_val &= (~(0x1<<5));	
		
	if(EMAC_MAC_VC)
		reg_val |= (0x1<<6);
	else
		reg_val &= (~(0x1<<6));	
		
	if(EMAC_MAC_ADP)
		reg_val |= (0x1<<7);
	else
		reg_val &= (~(0x1<<7));	
		
	if(EMAC_MAC_PRE)
		reg_val |= (0x1<<8);
	else
		reg_val &= (~(0x1<<8));	
		
	if(EMAC_MAC_LPE)
		reg_val |= (0x1<<9);
	else
		reg_val &= (~(0x1<<9));	
		
	if(EMAC_MAC_NB)
		reg_val |= (0x1<<12);
	else
		reg_val &= (~(0x1<<12));	
		
	if(EMAC_MAC_BNB)
		reg_val |= (0x1<<13);
	else
		reg_val &= (~(0x1<<13));	
	
	if(EMAC_MAC_ED)
		reg_val |= (0x1<<14);
	else
		reg_val &= (~(0x1<<14));	

	writel(reg_val, db->emac_base + EMAC_MAC_CTL1_REG);
	
	//set up IPGT
	reg_val = EMAC_MAC_IPGT;
	writel(reg_val, db->emac_base + EMAC_MAC_IPGT_REG);
	
	//set up IPGR
	reg_val = EMAC_MAC_NBTB_IPG2;
    reg_val |= (EMAC_MAC_NBTB_IPG1<<8);
    writel(reg_val, db->emac_base + EMAC_MAC_IPGR_REG);
    
    //set up Collison window
    reg_val = EMAC_MAC_RM;
    reg_val |= (EMAC_MAC_CW<<8);
    writel(reg_val, db->emac_base + EMAC_MAC_CLRT_REG);
    
    //set up Max Frame Length
    reg_val = EMAC_MAC_MFL;
    writel(reg_val, db->emac_base + EMAC_MAC_MAXF_REG);
	
	
	return (1);
}

unsigned int wemac_powerup(wemac_board_info_t * db )
{
	unsigned int reg_val;
	unsigned char *mac_addr = DEFAULT_MAC_ADDR;
	
	//flush  RX FIFO
	reg_val = readl(db->emac_base + EMAC_RX_CTL_REG);   //RX FIFO 
	reg_val |= 0x8;	
	writel(reg_val, db->emac_base + EMAC_RX_CTL_REG);
	udelay(1);

	//initial MAC
	reg_val = readl(db->emac_base + EMAC_MAC_CTL0_REG);  //soft reset MAC
	reg_val &= (~(0x1<<15));	
	writel(reg_val, db->emac_base + EMAC_MAC_CTL0_REG);

	reg_val = readl(db->emac_base + EMAC_MAC_MCFG_REG);  // set MII clock
	reg_val &= (~(0xf<<2));
	reg_val |= (0xC<<2);
	writel(reg_val, db->emac_base + EMAC_MAC_MCFG_REG);

	//clear RX counter
	writel(0x0, db->emac_base + EMAC_RX_FBC_REG);

	//disable all interrupt and clear interrupt status
	writel(0, db->emac_base + EMAC_INT_CTL_REG);
	reg_val = readl(db->emac_base + EMAC_INT_STA_REG);
	writel(reg_val, db->emac_base + EMAC_INT_STA_REG);

	udelay(1);

	//set up EMAC
	emac_setup(db);

	writel(mac_addr[5]<<16 | mac_addr[4]<<8 | mac_addr[3], db->emac_base + EMAC_MAC_A0_REG);
	writel(mac_addr[2]<<16 | mac_addr[1]<<8 | mac_addr[0], db->emac_base + EMAC_MAC_A1_REG);

	udelay(1000);   
				
	return (1);
}

/*
 * Initilize wemac board
 */
static void
wemac_init_wemac(struct wemac_board_info *db)
{
	unsigned int phy_reg;
	unsigned int reg_val;

	/* PHY POWER UP */
	phy_reg = wemac_phy_read(db, 0, 0);
	wemac_phy_write(db, 0, 0, phy_reg & (~(1 <<11)));	
	udelay(1);

	phy_reg = wemac_phy_read(db, 0, 0);

	/* set EMAC SPEED, depend on PHY  */
	reg_val = readl(db->emac_base + EMAC_MAC_SUPP_REG);  
	reg_val &= (~(0x1<<8));
	reg_val |= ((phy_reg & (1<<13)) <<8);
	writel(reg_val, db->emac_base + EMAC_MAC_SUPP_REG);

	/* set duplex depend on phy*/
	reg_val = readl(db->emac_base + EMAC_MAC_CTL1_REG);  
	reg_val &= (~(0x1<<0));
	reg_val |= ((phy_reg & (1<<8)) <<0);
	writel(reg_val, db->emac_base + EMAC_MAC_CTL1_REG);

	/* enable RX/TX */
	reg_val = readl(db->emac_base + EMAC_CTL_REG);
	reg_val |= 0x3<<1;
	writel(reg_val, db->emac_base + EMAC_CTL_REG);

	/* enable RX/TX0/RX Hlevel interrup */
	reg_val = readl(db->emac_base + EMAC_INT_CTL_REG);
//	reg_val |= (0x1<<0) | (0x01<<8)| (0x1<<17);
	reg_val |= (0xf<<0) | (0x01<<8);
	writel(reg_val, db->emac_base + EMAC_INT_CTL_REG);

}

static int
wemac_transmit(struct eth_device *nic, volatile void *packet, int length)
{
	struct wemac_board_info *db = nic->priv;

	writel(0, db->emac_base + EMAC_TX_INS_REG);
	(db->outblk)(db->emac_base + EMAC_TX_IO_DATA_REG, (void *)packet, length);

	writel(length, db->emac_base + EMAC_TX_PL0_REG);
	/* start translate from fifo to phy */
	writel(readl(db->emac_base + EMAC_TX_CTL0_REG) | 1, db->emac_base + EMAC_TX_CTL0_REG);

	while( readl(db->emac_base + EMAC_TX_CTL0_REG) & 1 == 0 );
}

/*
 *  Received a packet and pass to upper layer
 */
static int
wemac_rx(wemac_board_info_t *db)
{
	struct wemac_rxhdr rxhdr;
	u8 *rdptr = wemac_packet;
	int GoodPacket;
	int RxLen, total_rxlen = 0;
	unsigned int RxStatus;
	unsigned int reg_val, Rxcount;

	/* Check packet ready or not */
	do {
		Rxcount = readl(db->emac_base + EMAC_RX_FBC_REG);

		if(!Rxcount){
			return total_rxlen;
		}
		
		reg_val = readl(db->emac_base + EMAC_RX_IO_DATA_REG);

		if(reg_val!=0x0143414d){
			//disable RX
			reg_val = readl(db->emac_base + EMAC_CTL_REG);
			writel(reg_val & (~(1<<2)), db->emac_base + EMAC_CTL_REG);
			
			//Flush RX FIFO
			reg_val = readl(db->emac_base + EMAC_RX_CTL_REG);
			writel(reg_val | (1<<3), db->emac_base + EMAC_RX_CTL_REG);
			
			while(readl(db->emac_base + EMAC_RX_CTL_REG)&(0x1<<3));
			
			//enable RX
			reg_val = readl(db->emac_base + EMAC_CTL_REG);
			writel(reg_val |(1<<2), db->emac_base + EMAC_CTL_REG);

			return total_rxlen;
		}

		/* A packet ready now  & Get status/length */
		GoodPacket = 1;

		(db->inblk)(db->emac_base + EMAC_RX_IO_DATA_REG, &rxhdr, sizeof(rxhdr));

		RxLen = rxhdr.RxLen;
		RxStatus = rxhdr.RxStatus; 

		/* Packet Status check */
		if (RxLen < 0x40) {
			GoodPacket = 0;
			printf("RX: Bad Packet (runt)\n");
		}

		/* RxStatus is identical to RSR register. */
		if (0 & RxStatus & (EMAC_CRCERR | EMAC_LENERR)) {
			GoodPacket = 0;
			if (RxStatus & EMAC_CRCERR) {
				printf("crc error\n");
			}
			if (RxStatus & EMAC_LENERR) {
				printf("length error\n");
			}
		}

		/* Move data from WEMAC */
		if (GoodPacket) {
			(db->inblk)(db->emac_base + EMAC_RX_IO_DATA_REG, rdptr, RxLen);
			rdptr += RxLen;
			total_rxlen += RxLen;
		} else {
			/* need to dump the packet's data */
			(db->dumpblk)(db->emac_base, RxLen);
		}
	} while (1);

	return total_rxlen;
}


/**************************************************************************
POLL - Wait for a frame
***************************************************************************/
static int
wemac_poll(struct eth_device *nic)
{
	struct wemac_board_info *db = nic->priv;
	int rx_count;
	int rx_len;

	rx_count = readl(db->emac_base + EMAC_RX_FBC_REG);	/* Got ISR */
	if ( rx_count == 0)
		return 0;
	rx_len = wemac_rx(db);
	if ( rx_len == 0)
		return 0;

	NetReceive((uchar *)wemac_packet, rx_len);

	return 1;
}


/*
 *   Read a word from phyxcer
 */
static int
wemac_phy_read(wemac_board_info_t * db, int phyaddr_unused, int reg)
{
	int ret;

	/* issue the phy address and reg */
    writel(WEMAC_PHY | reg, db->emac_base + EMAC_MAC_MADR_REG);
	/* pull up the phy io line */
    writel(0x1, db->emac_base + EMAC_MAC_MCMD_REG);

	udelay(500);

	/* push down the phy io line */
    writel(0x0, db->emac_base + EMAC_MAC_MCMD_REG);
	/* and write data */
    ret = readl(db->emac_base + EMAC_MAC_MRDD_REG);

	return ret;
}

/*
 *   Write a word to phyxcer
 */
static void
wemac_phy_write(wemac_board_info_t * db,
		 int phyaddr_unused, int reg, int value)
{
	/* issue the phy address and reg */
    writel(WEMAC_PHY | reg, db->emac_base + EMAC_MAC_MADR_REG);
	/* pull up the phy io line */
    writel(0x1, db->emac_base + EMAC_MAC_MCMD_REG);

	udelay(500);

	/* push down the phy io line */
    writel(0x0, db->emac_base + EMAC_MAC_MCMD_REG);
	/* and write data */
    writel(reg, db->emac_base + EMAC_MAC_MWTD_REG);
}

static void
wemac_shutdown(struct eth_device *nic)
{
	struct wemac_board_info *db = nic->priv;
	unsigned int reg_val;

	/* RESET device */
	reg_val = wemac_phy_read(db, 0, 0);
	wemac_phy_write(db, 0, 0, reg_val | (1 <<15));	/* PHY RESET */
	udelay(10);
	reg_val = wemac_phy_read(db, 0, 0);
	if(reg_val & (1<<15))
		printf("phy_reset not complete. value of reg0: %x\n", reg_val);
	
	wemac_phy_write(db, 0, 0, reg_val | (1 <<11));	/* PHY POWER DOWN */
	writel(0, db->emac_base + EMAC_INT_CTL_REG);					/* Disable all interrupt */
	writel(readl(db->emac_base + EMAC_INT_STA_REG), db->emac_base + EMAC_INT_STA_REG);          /* clear interupt status */
	writel(readl(db->emac_base + EMAC_CTL_REG) & (~(0x1<<2)), db->emac_base + EMAC_CTL_REG);	/* Disable RX */
}

static int
wemac_init(struct eth_device *nic, bd_t * bis)
{
	struct wemac_board_info *db = nic->priv;

	emac_sys_setup(db);
	wemac_powerup(db);
	wemac_reset(db);
	wemac_init_wemac(db);

	return 0;
}

int
wemac_initialize(bd_t * bis)
{
	struct eth_device *nic = NULL;
	struct wemac_board_info *db;
	int i, ret = 0;

	nic = (struct eth_device *) malloc(sizeof (*nic));
	db = (struct wemac_board_info *) malloc(sizeof (*db));
	memset(nic, 0, sizeof(*nic));
	memset(db, 0, sizeof(*db));
	nic->priv = db;

	sprintf(nic->name, "WEMAC");

	db->emac_base = (char*)EMAC_BASE;
	db->sram_base = (char*)SRAMC_BASE;
	db->gpio_base = (char*)PIO_BASE;
	db->ccmu_base = (char*)CCM_BASE;

	/* ensure at least we have a default set of IO routines */
	db->dumpblk = wemac_dumpblk_32bit;
	db->outblk  = wemac_outblk_32bit;
	db->inblk   = wemac_inblk_32bit;

//	for (i = 0; i < 6; i++)
//		nic->enetaddr[i] = DEFAULT_MAC_ADDR[i];

	nic->init = wemac_init;
	nic->recv = wemac_poll;
	nic->send = wemac_transmit;
	nic->halt = wemac_shutdown;
	
	eth_register(nic);
	
	return 0;
}

