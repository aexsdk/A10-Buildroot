/*
 * COM1 NS16550 support
 * originally from linux source (arch/ppc/boot/ns16550.c)
 * modified to use CFG_ISA_MEM and new defines
 */

#include <config.h>

#ifdef CFG_NS16550

#include <ns16550.h>

#define LCRVAL LCR_8N1					/* 8 data, 1 stop, no parity */
#define MCRVAL (MCR_DTR | MCR_RTS)			/* RTS/DTR */
#define FCRVAL (FCR_FIFO_EN | FCR_RXSR | FCR_TXSR)	/* Clear & enable FIFOs */

#ifdef AW1623_UART


void NS16550_init (NS16550_t com_port, int baud_divisor)
{
    /* disable all interrupt */
	com_port->ier = 0x00;
    /* enable fifo, reset tx and rx fifo */
    com_port->fcr = 0x07;

    /* set band rate */
    while(com_port->usr & 0x01);
    com_port->lcr = 0x80;
    com_port->dll = (baud_divisor & 0xff);
    com_port->dlm = ((baud_divisor>>8) & 0xff);
    while(com_port->usr & 0x01);
    com_port->lcr = 0x00;

    /* set data bits length, 8bit */
    while(com_port->usr & 0x01);
    com_port->lcr |= 0x03;
    /* set stop bits */
    while(com_port->usr & 0x01);
    com_port->lcr |= 0x04;
}

void NS16550_reinit (NS16550_t com_port, int baud_divisor)
{
	com_port->ier = 0x00;
	com_port->lcr = LCR_BKSE | LCRVAL;
	com_port->dll = 0;
	com_port->dlm = 0;
	com_port->lcr = LCRVAL;
	com_port->mcr = MCRVAL;
	com_port->fcr = FCRVAL;
	com_port->lcr = LCR_BKSE;
	com_port->dll = baud_divisor & 0xff;
	com_port->dlm = (baud_divisor >> 8) & 0xff;
	com_port->lcr = LCRVAL;
}


#else


#ifdef CONFIG_SW1651X
static void _for_loop(unsigned int loop)
{
	unsigned int i;

	for( i = 0; i < loop; i++ )
		;
}
#endif

void NS16550_init (NS16550_t com_port, int baud_divisor)
{
#ifdef CONFIG_SW1651X
	switch ((int)com_port) {
		case CFG_NS16550_COM1:
			_clear_bit( CCMU_REG_APBMOD, CCMU_BP_UART0_APB_GATE );
			_for_loop(100);
			_set_bit( CCMU_REG_APBMOD, CCMU_BP_UART0_APB_GATE );
			//only set to gpio 0 CFG
			PIOC_REG_B_PULL0 &= ~( ( 3<<4 ) | ( 3<<8 ) );
			PIOC_REG_B_PULL0 |=	( ( 1<<4 ) | ( 1<<8 ) );
			PIOC_REG_B_CFG0  &= ~( ( 7<<16 ) | ( 7<<8 ) );
			PIOC_REG_B_CFG0  |=	( ( 4<<16 ) | ( 4<<8 ) );
			break;

		case CFG_NS16550_COM2:
			_clear_bit( CCMU_REG_APBMOD, CCMU_BP_UART1_APB_GATE );
			_for_loop(100);
			_set_bit( CCMU_REG_APBMOD, CCMU_BP_UART1_APB_GATE );
			//only set to gpio 0 CFG
			PIOC_REG_B_PULL0 &= ~( ( 3<<18 ) | ( 3<<20 ) );
			PIOC_REG_B_PULL0 |=	( ( 1<<18 ) | ( 1<<20 ) );
			PIOC_REG_B_CFG1  &= ~( ( 7<<4 ) | ( 7<<8 ) );
			PIOC_REG_B_CFG1  |=	( ( 2<<4 ) | ( 2<<8 ) );
			break;

		case CFG_NS16550_COM3:
			_clear_bit( CCMU_REG_APBMOD, CCMU_BP_UART2_APB_GATE );
			_for_loop(100);
			_set_bit( CCMU_REG_APBMOD, CCMU_BP_UART2_APB_GATE );
			//only set to gpio 0 CFG
			PIOC_REG_B_PULL1 &= ~( ( 3<<0 ) | ( 3<<2 ) );
			PIOC_REG_B_PULL1 |=	( ( 1<<0 ) | ( 1<<2 ) );
			PIOC_REG_B_CFG2  &= ~( ( 7<<4 ) | ( 7<<0 ) );
			PIOC_REG_B_CFG2  |=	( ( 2<<4 ) | ( 2<<0 ) );
			break;

		case CFG_NS16550_COM4:
			_clear_bit( CCMU_REG_APBMOD, CCMU_BP_UART3_APB_GATE );
			_for_loop(100);
			_set_bit( CCMU_REG_APBMOD, CCMU_BP_UART3_APB_GATE );
			//only set to gpio 0 CFG
			PIOC_REG_A_PULL0 &= ~( ( 3<<0 ) | ( 3<<2 ) );
			PIOC_REG_A_PULL0 |=	( ( 1<<0 ) | ( 1<<2 ) );
			PIOC_REG_A_CFG0  &= ~( ( 7<<4 ) | ( 7<<0 ) );
			PIOC_REG_A_CFG0  |=	( ( 3<<4 ) | ( 3<<0 ) );
			break;
	}
#endif

	com_port->ier = 0x00;
#ifdef CONFIG_OMAP
	com_port->mdr1 = 0x7;	/* mode select reset TL16C750*/
#endif
	com_port->lcr = LCR_BKSE | LCRVAL;
	com_port->dll = baud_divisor & 0xff;
	com_port->dlm = (baud_divisor >> 8) & 0xff;
	com_port->lcr = LCRVAL;
	com_port->mcr = MCRVAL;
	com_port->fcr = FCRVAL;
#if defined(CONFIG_OMAP)
#if defined(CONFIG_APTIX)
	com_port->mdr1 = 3;	/* /13 mode so Aptix 6MHz can hit 115200 */
#else
	com_port->mdr1 = 0;	/* /16 is proper to hit 115200 with 48MHz */
#endif
#endif
}

void NS16550_reinit (NS16550_t com_port, int baud_divisor)
{
	com_port->ier = 0x00;
	com_port->lcr = LCR_BKSE;
	com_port->dll = baud_divisor & 0xff;
	com_port->dlm = (baud_divisor >> 8) & 0xff;
	com_port->lcr = LCRVAL;
	com_port->mcr = MCRVAL;
	com_port->fcr = FCRVAL;
}

#endif

char NS16550_getc (NS16550_t com_port)
{
	while ((com_port->lsr & LSR_DR) == 0) ;
	return (com_port->rbr);
}

void NS16550_putc (NS16550_t com_port, char c)
{
	while ((com_port->lsr & LSR_THRE) == 0);
	com_port->thr = c;
}

int NS16550_tstc (NS16550_t com_port)
{
	return ((com_port->lsr & LSR_DR) != 0);
}


#endif
