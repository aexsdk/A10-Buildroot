/*
  aw_emac.c: Version 1.0 11/04/2011

	A Davicom EMAC ISA NIC fast Ethernet driver for Linux.
	Copyright (C) 2011

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

  (C)Copyright 2011 AllWinner. All Rights Reserved.

*/

#include <common.h>
#include <command.h>
#include <net.h>
#include <asm/io.h>

#include "aw_emac.h"

#if CONFIG_DRIVER_AWEMAC

typedef struct wemac_board_info {

	char *emac_base;	/* mac I/O base address */
	char *sram_base;	/* sram control I/O base address */
	char *gpio_base;	/* gpio I/O base address */
	char *ccmu_base;	/* ccmu I/O base address */

	void (*inblk)(void  *port, void *data, int length);
	void (*outblk)(void  *port, void *data, int length);
	void (*dumpblk)(void  *port, int length);

} wemac_board_info_t;

/**
 * is_zero_ether_addr - Determine if give Ethernet address is all zeros.
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Return true if the address is all zeroes.
 */
static inline int is_zero_ether_addr(const u8 *addr)
{
	return !(addr[0] | addr[1] | addr[2] | addr[3] | addr[4] | addr[5]);
}

/**
 * is_multicast_ether_addr - Determine if the Ethernet address is a multicast.
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Return true if the address is a multicast address.
 * By definition the broadcast address is also a multicast address.
 */
static inline int is_multicast_ether_addr(const u8 *addr)
{
	return (0x01 & addr[0]);
}

#ifdef CONFIG_EMAC_DEBUG
#define EMAC_DBG(fmt,args...) printf(fmt, ##args)
#define EMAC_DMP_PACKET(func,packet,length)  \
	do { \
		int i; 							\
		printf(func ": length: %d\n", length);			\
		for (i = 0; i < length; i++) {				\
			if (i % 8 == 0)					\
				printf("\n%s: %02x: ", func, i);	\
			printf("%02x ", ((unsigned char *) packet)[i]);	\
		} printf("\n");						\
	} while(0)
#else
#define EMAC_DBG(fmt,args...)
#define EMAC_DMP_PACKET(func,packet,length)
#endif

/* Structure/enum declaration ------------------------------- */
typedef struct board_info {
	u32 runt_length_counter;	/* counter: RX length < 64byte */
	u32 long_length_counter;	/* counter: RX length > 1514byte */
	u16 tx_pkt_cnt;
	u16 queue_start_addr;
	u16 dbug_cnt;
	u8 phy_addr;
	void (*outblk)(volatile void *data_ptr, int count);
	void (*inblk)(void *data_ptr, int count);
	void (*dump)(int count);
} board_info_t;
static board_info_t emac_info;

/* function declaration ------------------------------------- */
int eth_init(bd_t * bd);
int eth_send(volatile void *, int);
int eth_rx(void);
void eth_halt(void);
static int emac_probe(void);
static u16 phy_read(int);
static void phy_write(int, u16);
static u32 EMAC_ior(int);
static void EMAC_iow(int reg, u32 value);
static int phy_set_100M(void);
static void emac_cfg(void);

/* EMAC network board routine ---------------------------- */

#define emac_writel(d,r) ( *(volatile u32 *)(r) = (d))
#define emac_readl(r) (*(volatile u32 *)(r))

static void emac_outblk_32bit(volatile void *data_ptr, int count)
{
	int i;
	u32 tmplen = (count + 3) >> 2;

	for (i = 0; i < tmplen; i++)
		emac_writel(((u32 *) data_ptr)[i], EMAC_BASE + EMAC_TX_IO_DATA_REG);
}

static void emac_inblk_32bit(void *data_ptr, int count)
{
	int i;
	u32 tmplen = (count + 3) / 4;

	for (i = 0; i < tmplen; i++)
		((u32 *) data_ptr)[i] = emac_readl(EMAC_BASE + EMAC_RX_IO_DATA_REG);
}
static void emac_dump_32bit(int count)
{
	int i, tmp;
	u32 tmplen = (count + 3) / 4;
	for(i=0; i < tmplen; i++)
		tmp = emac_readl(EMAC_BASE + EMAC_RX_IO_DATA_REG);
}

/*
  Search EMAC board, allocate space and register it
*/
static int
emac_probe(void)
{
	unsigned int reg_val;

	EMAC_DBG("%s:\n", __FUNCTION__);

	/* Flush Rx FIFO */
	reg_val = readl(EMAC_BASE + EMAC_RX_CTL_REG);
	reg_val |= 0x08;
	emac_writel(reg_val, EMAC_BASE + EMAC_RX_CTL_REG);
	udelay(10);

	/* initial MAC */
	reg_val = readl(EMAC_BASE + EMAC_MAC_CTL0_REG);
	reg_val &= (~(0x1 << 15));
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_CTL0_REG);
	EMAC_DBG("\EMAC_MAC_CTL0_REG %08x\n", emac_readl(EMAC_BASE + EMAC_MAC_CTL0_REG));

	/* set MII clock */
	reg_val = readl(EMAC_BASE + EMAC_MAC_MCFG_REG);
	reg_val &= (~(0xf<<2));
	reg_val |= (0xc<<2);
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_MCFG_REG);

	reg_val = readl(EMAC_BASE + EMAC_MAC_SUPP_REG);
	reg_val &= (~(0x1<<8));
	reg_val |= (PHY_SPEED<<2);
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_SUPP_REG);

	/* clear Rx counter */
	emac_writel(0x00, EMAC_BASE + EMAC_RX_FBC_REG);

	/* disable all interrupt and clear interrupt status */
	emac_writel(0, EMAC_BASE + EMAC_INT_CTL_REG);
	reg_val = readl(EMAC_BASE + EMAC_INT_STA_REG);
	emac_writel(reg_val, EMAC_BASE + EMAC_INT_STA_REG);
	udelay(100);
	EMAC_DBG("\tEMAC_INT_STA_REG %08x\n", emac_readl(EMAC_BASE + EMAC_INT_STA_REG));

	return 0;
}

/* Set PHY operationg mode
*/
static void
set_PHY_mode(void)
{
	int reg_val;

	EMAC_DBG("%s:\n", __FUNCTION__);

#if PHY_8201CP
	if(!PHY_AUTO_NEGOTIOATION){
		reg_val = phy_read(0x00);
		reg_val |= (0x01<<8) | (0x01<<13);
		phy_write(0x00, reg_val);
		EMAC_DBG("set phy reg0: 0x%x\n", reg_val);
		if(reg_val != phy_read(0x00))
			EMAC_DBG("EMAC PHY setting error!\n");
	}else{
		EMAC_DBG("EMAC PHY AUTO!\n");
	}
#endif

#ifdef PHY_1000M
	reg_val = phy_read(0x00);
	reg_val |= (0x01<<15);
	phy_write(0x00, reg_val);
	EMAC_DBG("1000M PHY Reset!\n");
	EMAC_DBG("PHY reg0:%08x  reg1:%08x\n", phy_read(0), phy_read(1));
	while(phy_read(0x00) & (0x01<<15)){
		udelay(100);
		EMAC_DBG("PHY Reseting, reg:%04x \n", phy_read(0x00));
	}
	EMAC_DBG("1000M PHY Reset OK\n");

	while(phy_read(0x00) & (0x01<<10)){
		reg_val = phy_read(0x00);
		reg_val &= (~(0x01<<10));
		phy_write(0x0, reg_val);
	}

	//reg_val = phy_read(0x00);
	//reg_val |= (0x01<<9);
	//phy_write(0x00, reg_val);
	udelay(1000);
	EMAC_DBG("PHY reg0:%08x  reg1:%08x\n", phy_read(0), phy_read(1));

	//force phy speed to 100M
	phy_set_100M();


#endif

}

static int
phy_check(void)
{

    if(phy_read(1)&0x4){
        EMAC_DBG("phy linked..........\n");
        return 0;
    }
    EMAC_DBG("phy link waiting......\n");
    return 1;
}

static int
phy_set_100M(void)
{
    u32 reg_val0;

    //disable auto nego, set speed to 100M
    reg_val0 = phy_read(0);
    reg_val0 &= (~(0x1<<6));
    reg_val0 |= (0x1<<13);
    reg_val0 &= (~(0x1<<12));
    phy_write(0, reg_val0);
    udelay(10000);
    EMAC_DBG("phy set 100M, reg0: 0x%x\n", phy_read(0));

    return 1;
}


/* Setup the system for eamc */
static void
emac_sys_up(void)
{

	unsigned int reg_val;
	EMAC_DBG("%s:\n", __FUNCTION__);

	/* map sram to emac */
	reg_val = emac_readl(SRAM_BASE + SRAMC_CFG0_REG);
	reg_val &=(0xf<<2);
	reg_val |= (0x5<<2);
	emac_writel(reg_val, SRAM_BASE + SRAMC_CFG0_REG);
	EMAC_DBG("\tSRAM_CFG0:%08x, %08x\n", SRAM_BASE + SRAMC_CFG0_REG, emac_readl(SRAM_BASE + SRAMC_CFG0_REG));

	/* map gpio to emac */
	reg_val = 0x22222222;
	emac_writel(reg_val, GPIO_BASE + PA_CFG0_REG);
	emac_writel(reg_val, GPIO_BASE + PA_CFG1_REG);
	emac_writel(reg_val, GPIO_BASE + PA_CFG2_REG);
	EMAC_DBG("\tPA_CFG0:%08x\n", emac_readl(GPIO_BASE + PA_CFG0_REG));
	EMAC_DBG("\tPA_CFG1:%08x\n", emac_readl(GPIO_BASE + PA_CFG1_REG));
	EMAC_DBG("\tPA_CFG2:%08x\n", emac_readl(GPIO_BASE + PA_CFG2_REG));

	/* setup ccmu to emac */
	reg_val = emac_readl(CCMU_BASE + CCMU_AHB_GATE_REG);
	reg_val |= (0x01 << 17);
	emac_writel(reg_val, CCMU_BASE + CCMU_AHB_GATE_REG);
	EMAC_DBG("\tCCMU_AHB:%08x\n", emac_readl(CCMU_BASE + CCMU_AHB_GATE_REG));

}

/*
 * config emac
 */
static void
emac_cfg(void)
{
	unsigned int reg_val;
	unsigned int phy_reg;
#if 0
	EMAC_DBG("EMAC seting --->\n"
           "PHY_AUTO_NEGOTIOATION  %x  0: Normal        1: Auto                 \n"
           "PHY_SPEED              %x  0: 10M           1: 100M                 \n"
           "EMAC_MAC_FULL          %x  0: Half duplex   1: Full duplex          \n"
           "EMAC_TX_TM             %x  0: CPU           1: DMA                  \n"
           "EMAC_TX_AB_M           %x  0: Disable       1: Aborted frame enable \n"
           "EMAC_RX_TM             %x  0: CPU           1: DMA                  \n"
           "EMAC_RX_DRQ_MODE       %x  0: DRQ asserted  1: DRQ automatically    \n"
           ,PHY_AUTO_NEGOTIOATION
           ,PHY_SPEED
           ,EMAC_MAC_FULL
           ,EMAC_TX_TM
           ,EMAC_TX_AB_M
           ,EMAC_RX_TM
	   ,EMAC_RX_DRQ_MODE);

	EMAC_DBG("%s:\n", __FUNCTION__);
#endif
	/* config tx */
	reg_val = emac_readl(EMAC_BASE + EMAC_TX_MODE_REG);
	CFG(EMAC_TX_AB_M, reg_val, 0);
	CFG(EMAC_TX_TM, reg_val, 1);
	emac_writel(reg_val, EMAC_BASE + EMAC_TX_MODE_REG);
	EMAC_DBG("\tTX_MODE_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_TX_MODE_REG));

	/* config rx */
	reg_val = emac_readl(EMAC_BASE + EMAC_RX_CTL_REG);
	CFG(EMAC_RX_DRQ_MODE, reg_val, 1);
	CFG(EMAC_RX_TM, reg_val, 2);
	CFG(EMAC_RX_PA, reg_val, 4),
	CFG(EMAC_RX_PCF, reg_val, 5);
	CFG(EMAC_RX_PCRCE, reg_val, 6);
	CFG(EMAC_RX_PLE, reg_val, 7);
	CFG(EMAC_RX_POR, reg_val, 8);
	CFG(EMAC_RX_UCAD, reg_val, 16);
	CFG(EMAC_RX_DAF, reg_val, 17);
	CFG(EMAC_RX_MCO, reg_val, 20);
	CFG(EMAC_RX_MHF, reg_val, 21);
	CFG(EMAC_RX_BCO, reg_val, 22);
	CFG(EMAC_RX_SAF, reg_val, 24);
	CFG(EMAC_RX_SAIF, reg_val, 25);
	emac_writel(reg_val, EMAC_BASE + EMAC_RX_CTL_REG);
	EMAC_DBG("\tEMAC_RX_CTL_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_RX_CTL_REG));

	/* config MAC CTL0 */
	reg_val = emac_readl(EMAC_BASE + EMAC_MAC_CTL0_REG);
	CFG(EMAC_MAC_TFC, reg_val, 3);
	CFG(EMAC_MAC_RFC, reg_val, 25);
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_CTL0_REG);
	EMAC_DBG("\tEMAC_MAC_CTL0_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_MAC_CTL0_REG));

	/* config MAC CTL1 */
	reg_val = emac_readl(EMAC_BASE + EMAC_MAC_CTL1_REG);
#if PHY_AUTO_NEGOTIOATION
	phy_reg = (phy_read(0x00) & 0x100);
	//phy_reg |= 0x01;
	reg_val |= 0x01;
#else
	CFG(EMAC_MAC_FULL, reg_val, 0);
#endif
	CFG(EMAC_MAC_FLC, reg_val, 1);
	CFG(EMAC_MAC_HF, reg_val, 2);
	CFG(EMAC_MAC_DCRC, reg_val, 3);
	CFG(EMAC_MAC_CRC, reg_val, 4);
	CFG(EMAC_MAC_PC, reg_val, 5);
	CFG(EMAC_MAC_VC, reg_val, 6);
	CFG(EMAC_MAC_ADP, reg_val, 7);
	CFG(EMAC_MAC_PRE, reg_val, 8);
	CFG(EMAC_MAC_LPE, reg_val, 9);
	CFG(EMAC_MAC_NB, reg_val, 12);
	CFG(EMAC_MAC_BNB, reg_val, 13);
	CFG(EMAC_MAC_ED, reg_val, 14);
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_CTL1_REG);
	EMAC_DBG("\tEMAC_MAC_CTL1_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_MAC_CTL1_REG));

	/* set up IPGT */
	reg_val = EMAC_MAC_IPGT;
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_IPGT_REG);
	EMAC_DBG("\tEMAC_MAC_IPGT_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_MAC_IPGT_REG));

	/* set up IPGR */
	reg_val = EMAC_MAC_NBTB_IPG2;
	reg_val |= (EMAC_MAC_NBTB_IPG1 << 8);
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_IPGR_REG);
	EMAC_DBG("\tEMAC_MAC_IPGR_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_MAC_IPGR_REG));

	/* set up Collison window */
	reg_val = EMAC_MAC_RM;
	reg_val |= (EMAC_MAC_CW << 8);
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_CLRT_REG);
	EMAC_DBG("\tEMAC_MAC_CLRT_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_MAC_CLRT_REG));

	/* set up Max Frame Length */
	reg_val = EMAC_MAC_MFL;
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_MAXF_REG);
	EMAC_DBG("\tEMAC_MAC_MAXF_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_MAC_MAXF_REG));

	/* disable RX/TX interrupt */
	reg_val = readl(EMAC_BASE + EMAC_INT_CTL_REG);
	reg_val &= (~(0xf<<0)) | (~(0x01<<8));
	emac_writel(reg_val, EMAC_BASE + EMAC_INT_CTL_REG);
	EMAC_DBG("\tEMAC_INT_CTL_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_INT_CTL_REG));

	/* enable Rx/Tx */
	reg_val = readl(EMAC_BASE + EMAC_CTL_REG);
	reg_val |= 0x3<<1;
	emac_writel(reg_val, EMAC_BASE + EMAC_CTL_REG);
	EMAC_DBG("\tEMAC_CTL_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_CTL_REG));

	/* set EMAC SPEED, depend on PHY */
	reg_val = readl(EMAC_BASE + EMAC_MAC_SUPP_REG);
	phy_reg = phy_read(0x00);
	reg_val &= (~(0x01<<8));
	reg_val |= (0x01<<8);
//	reg_val |= ((phy_reg & (0x01<<13)) << 8);
	emac_writel(reg_val, EMAC_BASE + EMAC_MAC_SUPP_REG);
	EMAC_DBG("\tEMAC_MAC_SUPP_REG: %08x\n", emac_readl(EMAC_BASE + EMAC_MAC_SUPP_REG));
}

/* General Purpose emac reset routine */
static void
emac_reset(void)
{
	EMAC_DBG("resetting EMAC\n");

	/* Reset EMAC */
	EMAC_iow(EMAC_CTL_REG, 0x00);
	udelay(100);
	EMAC_iow(EMAC_CTL_REG, 0x07);
	udelay(100);
}

/* Initilize emac board
*/
int
aw_eth_init(struct eth_device *nic, bd_t * bd)
{
	int i, oft;
	struct board_info *db = &emac_info;
	unsigned char *mac_addr = &(bd->bi_enetaddr[0]);

	EMAC_DBG("eth_init()\n");

	emac_sys_up();
	emac_probe();

	/* RESET device */
	emac_reset();

	/* config MAC */
	emac_cfg();

	/* Set PHY */
	set_PHY_mode();
	while(phy_check()){
	    udelay(10000);
        EMAC_DBG("reg0: %08x reg1: %08x\n", phy_read(0), phy_read(1));
	}

	db->outblk    = emac_outblk_32bit;
	db->inblk     = emac_inblk_32bit;
	db->dump      = emac_dump_32bit;

	if (is_zero_ether_addr(bd->bi_enetaddr) ||
	    is_multicast_ether_addr(bd->bi_enetaddr)) {
		/* try reading from environment */
		u8 i;
		char *s, *e;
		s = getenv ("ethaddr");
		for (i = 0; i < 6; ++i) {
			bd->bi_enetaddr[i] = s ?
				simple_strtoul (s, &e, 16) : 0;
			if (s)
				s = (*e) ? e + 1 : e;
		}
	}

	printf("MAC: %02x:%02x:%02x:%02x:%02x:%02x\n", mac_addr[0],
	       mac_addr[1], mac_addr[2], mac_addr[3],
	       mac_addr[4], mac_addr[5]);
	emac_writel(mac_addr[3]<<16 | mac_addr[4]<<8 | mac_addr[5], \
		EMAC_BASE + EMAC_MAC_A0_REG);
	emac_writel(mac_addr[0]<<16 | mac_addr[1]<<8 | mac_addr[2], \
		EMAC_BASE + EMAC_MAC_A1_REG);

#ifdef CONFIG_EMAC_DEBUG
	/* read back mac, just to be sure */
	oft = EMAC_ior(EMAC_MAC_A1_REG);
		EMAC_DBG("%02x:%02x:%02x:", (u8)(oft>>16), (u8)(oft>>8), (u8)(oft>>0));
	oft = EMAC_ior(EMAC_MAC_A0_REG);
		EMAC_DBG("%02x:%02x:%02x\n", (u8)(oft>>16), (u8)(oft>>8), (u8)(oft>>0));
#endif

#if 0
	/* see what we've got */
	lnk = phy_read(17) >> 12;
	printf("operating at ");
	switch (lnk) {
	case 1:
		printf("10M half duplex ");
		break;
	case 2:
		printf("10M full duplex ");
		break;
	case 4:
		printf("100M half duplex ");
		break;
	case 8:
		printf("100M full duplex ");
		break;
	default:
		printf("unknown: %d ", lnk);
		break;
	}
	printf("mode\n");
#endif
	return 0;
}

/*
  Hardware start transmission.
  Send a packet to media from the upper layer.
*/
int
aw_eth_send(struct eth_device *nic, volatile void *packet, int length)
{
	int tmo;
	struct board_info *db = &emac_info;
	unsigned int tmp;

	EMAC_DMP_PACKET("eth_send", packet, length);
	EMAC_DBG("\n%s:\n", __FUNCTION__);

	/* Move data to EMAC TX RAM */
	emac_writel(0, EMAC_BASE + EMAC_TX_INS_REG); /* Prepare for TX-data */

	/* Set TX length to EMAC */
	EMAC_iow(EMAC_TX_PL0_REG, length);
	EMAC_DBG("\tEMAC_TX_PL0_REG:%08x", EMAC_ior(EMAC_TX_PL0_REG));

	/* push the data to the TX-fifo */
	(db->outblk)(packet, length);

	/* Tx index0 Request */
	tmp = readl(EMAC_BASE + EMAC_TX_CTL0_REG);
	tmp |= 0x01;
	emac_writel(tmp, EMAC_BASE + EMAC_TX_CTL0_REG);
	EMAC_DBG("\tEMAC_TX_CTL0_REG:%08x\n", EMAC_ior(EMAC_TX_CTL0_REG));
	/* wait for end of transmission */
	//tmo = get_timer(0) + 5 * CFG_HZ;
	while((readl(EMAC_BASE + EMAC_TX_CTL0_REG) & 0x01)){
		//if (get_timer(0) >= tmo) {
			//printf("transmission timeout\n");
		//	break;
		//}
	}
	EMAC_DBG("transmit done\n\n");
	return 0;
}

/*
  Stop the interface.
  The interface is stopped when it is brought.
*/
void
aw_eth_halt(struct eth_device *nic)
{
	u32 tmp_reg;

	EMAC_DBG("eth_halt\n");

	/* RESET devie */
	//tmp_reg = phy_read(0x00);
	//tmp_reg |= (0x01<<15);
	//phy_write(0, tmp_reg);	/* PHY RESET */

	EMAC_iow(EMAC_INT_CTL_REG, 0x00);	/* Disable all interrupt */
	tmp_reg = EMAC_ior(EMAC_CTL_REG);
	tmp_reg &= (~(0x01<<2));
	EMAC_iow(EMAC_CTL_REG, tmp_reg);		/* Disable RX */
}

/*
  Received a packet and pass to upper layer
*/
int
aw_eth_rx(struct eth_device *nic)
{
	u8 *rdptr = (u8 *) NetRxPackets[0];
	u16 RxStatus, RxLen = 0;
	unsigned int tmp_val;
	struct board_info *db = &emac_info;

	//EMAC_DBG("\n%s:\n", __FUNCTION__);

	/* There is _at least_ 1 package in the fifo, read them all */
	for (;;) {
		/* Check the FIFO Available */
		if(!readl(EMAC_BASE + EMAC_RX_FBC_REG))
		{
			return 0;
		}

		/* Check magic number */
		tmp_val = EMAC_ior(EMAC_RX_IO_DATA_REG);
		EMAC_DBG("first %08x\n", tmp_val);
		if(tmp_val !=0x0143414d){
			/* disable Rx */
			tmp_val = EMAC_ior(EMAC_CTL_REG);
			EMAC_iow(EMAC_CTL_REG, tmp_val & (~(0x01<<2)));

			/* Flush RX FIFO */
			tmp_val = EMAC_ior(EMAC_RX_CTL_REG);
			EMAC_iow(EMAC_RX_CTL_REG, tmp_val | (1<<3));
			while(EMAC_ior(EMAC_RX_CTL_REG) & (0x01<<3));

			/* enable Rx */
			tmp_val = EMAC_ior(EMAC_CTL_REG);
			EMAC_iow(EMAC_CTL_REG, tmp_val | (1<<2));

			puts("magic error\n");
			return 0;
		}

		/* Check revice status */
		tmp_val = EMAC_ior(EMAC_RX_IO_DATA_REG);
		EMAC_DBG("status %04x lenght %04x\n", tmp_val>>16, tmp_val & 0x0000ffff);
		RxLen = tmp_val & 0x0000ffff;
		RxStatus = tmp_val >> 16;
		if(RxLen < 0x40){
			(db->dump)(RxLen);
			printf("RX: Bad Packet (runt)\n");
			continue;
		}

#if 0
		if(RxStatus & (EMAC_CRCERR | EMAC_LENERR)){
			if(RxStatus & EMAC_CRCERR)
				printf("crc error\n");
			if(RxStatus & EMAC_LENERR)
				printf("length error");
			(db->dump)(RxLen);
			continue;
		}
#endif
		/* now receiving ture packet */
		EMAC_DBG("receiving packet\n");
		EMAC_DBG("rx status: 0x%04x rx len: %04x\n", RxStatus, RxLen);

		/* Move data from EMAC */
		/* Read received packet from RX SRAM */
		(db->inblk)(rdptr, RxLen);

        if(0xee == ((unsigned char *) rdptr)[0]){
		    EMAC_DMP_PACKET("eth_rx", rdptr, RxLen);
		}
		EMAC_DBG("passing packet to upper layer\n");
		NetReceive(NetRxPackets[0], RxLen);
	}
	return 0;
}

/*
   Read a byte from I/O port
*/
static u32
EMAC_ior(int reg)
{
	/* emac_writeb(reg, EMAC_BASE + reg); */
	return emac_readl(EMAC_BASE + reg);
}

/*
   Write a byte to I/O port
*/
static void
EMAC_iow(int reg, u32 value)
{
	/*emac_writeb(reg, EMAC_BASE);*/
	emac_writel(value, EMAC_BASE + reg);
}

/*
   Read a word from phyxcer
*/
static u16
phy_read(int reg)
{
	u16 val;

	/* Fill the phyxcer register into REG_0C */
	EMAC_iow(EMAC_MAC_MADR_REG, EMAC_PHY | reg);
	udelay(1000);
	EMAC_iow(EMAC_MAC_MCMD_REG, 0x01);	/* Issue phyxcer read command */
	udelay(1000);
	EMAC_iow(EMAC_MAC_MCMD_REG, 0x00);	/* Issue phyxcer read command */
	udelay(1000);
	val = EMAC_ior(EMAC_MAC_MRDD_REG);

	return val;
}

/*
   Write a word to phyxcer
*/
static void
phy_write(int reg, u16 value)
{
	/* Fill the phyxcer register into REG_0C */
	EMAC_iow(EMAC_MAC_MADR_REG, EMAC_PHY | reg);
	udelay(1000);
	EMAC_iow(EMAC_MAC_MWTD_REG, value);	/* Fill the written data */
	udelay(1000);                        /* Wait write complete */
}

int
aw_emac_initialize(bd_t * bis)
{
	struct eth_device *nic = NULL;
	struct wemac_board_info *db;
	int i, ret = 0;

	nic = (struct eth_device *) malloc(sizeof (*nic));
	db = (struct wemac_board_info *) malloc(sizeof (*db));
	memset(nic, 0, sizeof(*nic));
	memset(db, 0, sizeof(*db));
	nic->priv = db;

	sprintf(nic->name, "WEMAC");

	db->emac_base = (char*)0;
	db->sram_base = (char*)0;
	db->gpio_base = (char*)0;
	db->ccmu_base = (char*)0;

	/* ensure at least we have a default set of IO routines */
	db->dumpblk = emac_dump_32bit;
	db->outblk  = emac_outblk_32bit;
	db->inblk   = emac_inblk_32bit;

//	for (i = 0; i < 6; i++)
//		nic->enetaddr[i] = DEFAULT_MAC_ADDR[i];

	nic->init = aw_eth_init;
	nic->recv = aw_eth_rx;
	nic->send = aw_eth_send;
	nic->halt = aw_eth_halt;

	eth_register(nic);

	return 0;
}




#endif

