/*
************************************************************************************************************************
*                                                      eNand
*                                           Nand flash driver scan module
*
*                             Copyright(C), 2008-2009, SoftWinners Microelectronic Co., Ltd.
*											       All Rights Reserved
*
* File Name : nand_scan.c
*
* Author : Kevin.z
*
* Version : v0.1
*
* Date : 2008.03.27
*
* Description : This file scan the nand flash storage system, analyze the nand flash type
*               and initiate the physical architecture parameters.
*
* Others : None at present.
*
*
* History :
*
*  <Author>        <time>       <version>      <description>
*
* Kevin.z         2008.03.27      0.1          build the file
*
************************************************************************************************************************
*/
#include "../include/nand_oal.h"
#include "../include/nand_drv_cfg.h"
#include "../include/nand_type.h"
#include "../include/nand_physic.h"
#include "../include/nand_ndfc.h"



extern  struct __NandStorageInfo_t  NandStorageInfo;
extern int BOOT_NandGetPara(boot_nand_para_t *param);


void _InitNandPhyInfo(boot_nand_para_t *nand_info)
{
    NandStorageInfo.ChipCnt          = nand_info->ChipCnt          ;
    NandStorageInfo.ChipConnectInfo  = nand_info->ChipConnectInfo  ;
    NandStorageInfo.RbCnt            = nand_info->RbCnt            ;
    NandStorageInfo.RbConnectInfo	 = nand_info->RbConnectInfo	   ;
    NandStorageInfo.RbConnectMode	 = nand_info->RbConnectMode	   ;
    NandStorageInfo.BankCntPerChip   = nand_info->BankCntPerChip   ;
    NandStorageInfo.DieCntPerChip    = nand_info->DieCntPerChip    ;
    NandStorageInfo.PlaneCntPerDie   = nand_info->PlaneCntPerDie   ;
    NandStorageInfo.SectorCntPerPage = nand_info->SectorCntPerPage ;
    NandStorageInfo.PageCntPerPhyBlk = nand_info->PageCntPerPhyBlk ;
    NandStorageInfo.BlkCntPerDie     = nand_info->BlkCntPerDie     ;
    NandStorageInfo.OperationOpt     = nand_info->OperationOpt     ;
    NandStorageInfo.FrequencePar     = nand_info->FrequencePar     ;
    NandStorageInfo.EccMode          = nand_info->EccMode          ;
    NandStorageInfo.ValidBlkRatio    = nand_info->ValidBlkRatio    ;
	NandStorageInfo.NandChipId[0]    = nand_info->NandChipId[0]    ;
	NandStorageInfo.NandChipId[1]    = nand_info->NandChipId[1]    ;
	NandStorageInfo.NandChipId[2]    = nand_info->NandChipId[2]    ;
	NandStorageInfo.NandChipId[3]    = nand_info->NandChipId[3]    ;
	NandStorageInfo.NandChipId[4]    = nand_info->NandChipId[4]    ;
	NandStorageInfo.ReadRetryType    = nand_info->ReadRetryType    ;

}

/*
************************************************************************************************************************
*                           SEARCH NAND PHYSICAL ARCHITECTURE PARAMETER
*
*Description: Search the nand flash physical architecture parameter from the parameter table
*             by nand chip ID.
*
*Arguments  : pNandID           the pointer to nand flash chip ID;
*             pNandArchiInfo    the pointer to nand flash physical architecture parameter.
*
*Return     : search result;
*               = 0     search successful, find the parameter in the table;
*               < 0     search failed, can't find the parameter in the table.
************************************************************************************************************************
*/
int _CheckNandID(__u8 *pNandID)
{
    int j=0;

    //search the nand architecture parameter from the given manufacture nand table by nand ID
    while(1)
    {
        for(j=1; j<4; j++)
        {
            //0xff is matching all ID value
            if(pNandID[j] != NandStorageInfo.NandChipId[j])
            break;
        }

        if(j==4)
        {
           /*4 bytes of the nand chip ID are all matching, search parameter successful*/
            return 0;
        }

        break;
    }

    //search nand architecture parameter failed
    return -1;
}


/*
************************************************************************************************************************
*                           ANALYZE NAND FLASH STORAGE SYSTEM
*
*Description: Analyze nand flash storage system, generate the nand flash physical
*             architecture parameter and connect information.
*
*Arguments  : none
*
*Return     : analyze result;
*               = 0     analyze successful;
*               < 0     analyze failed, can't recognize or some other error.
************************************************************************************************************************
*/
int  BOOT_AnalyzeNandSystem(void)
{
    int result;
    uint i;
    __u8  tmpChipID[8];
    boot_nand_para_t nand_info;

    //init nand flash storage information to default value
    NandStorageInfo.ChipCnt = 1;
    NandStorageInfo.ChipConnectInfo = 1;
    NandStorageInfo.RbConnectMode= 1;
    NandStorageInfo.RbCnt= 1;
    NandStorageInfo.RbConnectInfo= 1;
    NandStorageInfo.BankCntPerChip = 1;
    NandStorageInfo.DieCntPerChip = 1;
    NandStorageInfo.PlaneCntPerDie = 1;
    NandStorageInfo.SectorCntPerPage = 4;
    NandStorageInfo.PageCntPerPhyBlk = 64;
    NandStorageInfo.BlkCntPerDie = 1024;
    NandStorageInfo.OperationOpt = 0;
    NandStorageInfo.FrequencePar = 10;
    NandStorageInfo.EccMode = 0;
    NandStorageInfo.NandChipId[0] = 0x55;
    NandStorageInfo.NandChipId[1] = 0xaa;
    NandStorageInfo.NandChipId[2] = 0x55;
    NandStorageInfo.NandChipId[3] = 0xaa;
	NandStorageInfo.ReadRetryType = 0;


    //reset the nand flash chip on boot chip select
    result = PHY_ResetChip(BOOT_CHIP_SELECT_NUM);
    result |= PHY_SynchBank(BOOT_CHIP_SELECT_NUM, SYNC_CHIP_MODE);
    if(result)
    {
        SCAN_ERR("[SCAN_ERR] Reset boot nand flash chip failed!\n");
        return -1;
    }

    //read nand flash chip ID from boot chip
    result = PHY_ReadNandId(BOOT_CHIP_SELECT_NUM, tmpChipID);
    if(result)
    {
        SCAN_ERR("[SCAN_ERR] Read chip ID from boot chip failed!\n");
        return -1;
    }
    SCAN_DBG("[SCAN_DBG] Nand flash chip id is:0x%x 0x%x 0x%x 0x%x\n",
            tmpChipID[0],tmpChipID[1],tmpChipID[2],tmpChipID[3]);

    //check nand ID
    if( BOOT_NandGetPara( &nand_info ) != 0 ){
		PRINT("[SCAN_DBG] get nand info from boot0 failed.\n");
		return -1;
	}
	SCAN_DBG("[SCAN_DBG] get nand id from boot0 is 0x%x 0x%x 0x%x 0x%x.\n", nand_info.NandChipId[0],nand_info.NandChipId[1],nand_info.NandChipId[2],nand_info.NandChipId[3]);

    _InitNandPhyInfo(&nand_info);
    result = _CheckNandID(tmpChipID);
    if(result)
    {
        //Generate nand flash physical archittecture parameter failed
        SCAN_ERR("[SCAN_ERR] check nand id failed!\n");
        SCAN_ERR("[SCAN_ERR] nand id from nand storage is 0x%x 0x%x 0x%x 0x%x \n",
                NandStorageInfo.NandChipId[0],NandStorageInfo.NandChipId[1],NandStorageInfo.NandChipId[2],NandStorageInfo.NandChipId[3]);
        return -1;
    }

     //set some configurable  optional operation parameter
    if(!CFG_SUPPORT_MULTI_PLANE_PROGRAM)
    {
        NandStorageInfo.OperationOpt &= ~NAND_MULTI_READ;
        NandStorageInfo.OperationOpt &= ~NAND_MULTI_PROGRAM;
    }

    if(!CFG_SUPPORT_INT_INTERLEAVE)
    {
        NandStorageInfo.OperationOpt &= ~NAND_INT_INTERLEAVE;
    }

    if(!CFG_SUPPORT_RANDOM)
    {
        NandStorageInfo.OperationOpt &= ~NAND_RANDOM;
    }

    if(!CFG_SUPPORT_READ_RETRY)
    {
        NandStorageInfo.OperationOpt &= ~NAND_READ_RETRY;
    }

    //process the plane count of a die and the bank count of a chip
    if(!SUPPORT_MULTI_PROGRAM)
    {
        NandStorageInfo.PlaneCntPerDie = 1;
    }

    if(!SUPPORT_INT_INTERLEAVE)
    {
        NandStorageInfo.BankCntPerChip = 1;
    }

    //process the external inter-leave operation
    if(CFG_SUPPORT_EXT_INTERLEAVE)
    {
        if(NandStorageInfo.ChipCnt > 1)
        {
            NandStorageInfo.OperationOpt |= NAND_EXT_INTERLEAVE;
        }
    }
    else
    {
        NandStorageInfo.OperationOpt &= ~NAND_EXT_INTERLEAVE;
    }

	/*configure page size*/
	{
		NFC_INIT_INFO nfc_info;
		nfc_info.bus_width = 0x0;
		nfc_info.ce_ctl = 0x0;
		nfc_info.ce_ctl1 = 0x0;
		nfc_info.debug = 0x0;
		nfc_info.pagesize = SECTOR_CNT_OF_SINGLE_PAGE;
		nfc_info.rb_sel = 1;
		nfc_info.serial_access_mode = 1;
		NFC_ChangMode(&nfc_info);
	}

	if(SUPPORT_READ_RETRY)
	{
		SCAN_DBG("NFC Read Retry Init. \n");
		NFC_ReadRetryInit(READ_RETRY_TYPE);

		for(i=0; i<NandStorageInfo.ChipCnt;i++)
	    {
	        PHY_GetDefaultParam(i);
	    }

	}

	//print nand flash physical architecture parameter
    SCAN_DBG("\n\n");
	SCAN_DBG("[SCAN_DBG]    Read Retry Type:      0x%x\n", NandStorageInfo.ReadRetryType);
    SCAN_DBG("[SCAN_DBG] =======================================================\n\n");

    return 0;
}
